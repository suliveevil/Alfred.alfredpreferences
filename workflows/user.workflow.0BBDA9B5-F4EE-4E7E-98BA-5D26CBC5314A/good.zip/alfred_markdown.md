# Bhishans-Alfred-Workflows

# Setting Python Default Link For Alfred
The Alfred looks python in the directory `/usr/bin/python`, If we do not have python installed in that directory we need to create
a soft link.

```
# For example
poudel at pisces in ~
$ which python
python is /usr/local/bin/python
#
# Then soft link one of the available python path.
ln -s /Users/poudel/Library/Enthought/Canopy/edm/envs/User/bin/python /usr/bin/python
```

# Using Alfred From Command Line
```
osascript -e "tell application \"Alfred 3\" to search \"vscode\""
```
